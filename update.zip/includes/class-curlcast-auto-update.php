<?php

/*
 * TODO: Maybe wire this up to github?
 * http://code.tutsplus.com/tutorials/distributing-your-plugins-in-github-with-automatic-updates--wp-34817
 */
