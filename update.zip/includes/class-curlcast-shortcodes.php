<?php

$curlcast_v2_shortcode_full = 'curlcast_full';
$curlcast_v2_shortcode_sidebar = 'curlcast_sidebar';
