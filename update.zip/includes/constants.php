<?php

define('CURLCAST_V2_RELEASE', '2.2.1');
define('CURLCAST_V2_DEFAULT_WIDGETS', 'http://widgets.curling.io');
define('CURLCAST_V2_DEFAULT_API', 'http://curling.io');
