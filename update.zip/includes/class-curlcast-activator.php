<?php

class Curlcast_Activator {

    public static function activate() {

    }

}
