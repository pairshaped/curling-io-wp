<?php

class Curlcast_Deactivator {

    public static function deactivate() {

    }

}
