<?php

define('CURLCAST_V2_RELEASE', '2.0.8');
