<iframe id="stats-frame-mini" src="{url}" frameborder="0" border="0" cellspacing="0"></iframe>
