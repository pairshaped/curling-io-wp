<div class="curlcast" id="competitions">
  <div class="container-fluid" id="curlcast_competitions">
  </div>
</div>
<script>
  React.renderComponent(
    CurlcastCompetitions({url: "{url}", pathPrefix: "{path_prefix}" }),
    document.getElementById('curlcast_competitions')
  );
</script>

