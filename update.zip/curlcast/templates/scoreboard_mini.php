<iframe id="stats-frame" class="mini" src="{url}" frameborder="0" border="0" cellspacing="0"></iframe>
